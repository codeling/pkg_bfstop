<?php
defined('_JEXEC') or die;

jimport('joomla.application.component.modeladmin');

class BfstopModelSettings extends JModelAdmin
{
	public function getForm($data = array(), $loadData = true)
	{
		return null;
	}
}
