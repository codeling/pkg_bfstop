<?php
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
	<th>
		<?php echo JText::_('COM_BFSTOP_HEADING_ID'); ?>
	</th>
	<th>
		<?php echo JText::_('COM_BFSTOP_HEADING_IPADDRESS'); ?>
	</th>
	<th>
		<?php echo JText::_('COM_BFSTOP_HEADING_CRDATE'); ?>
	</th>
	<th>
		<?php echo JText::_('COM_BFSTOP_HEADING_STATE'); ?>
	</th>
</tr>
