<?php
defined('_JEXEC') or die;
?>
<div>
	<?php echo $this->ipInfo; ?>
</div>
