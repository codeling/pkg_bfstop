<div class="message" >
Check the notification configuration of the bfstop plugin by clicking the button in the toolbar!<br/>
More settings will be added here in the future, stay tuned for next bfstop versions.
</div>
<form method="post" name="adminForm" id="adminForm">
	<input type="hidden" name="task" value="settings.testNotify" />
	<?php echo JHtml::_('form.token'); ?>
</form>
