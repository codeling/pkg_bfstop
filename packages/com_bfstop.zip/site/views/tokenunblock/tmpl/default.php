<?php
defined('_JEXEC') or die;
?>
<h1><?php echo JText::_('UNBLOCKTOKEN_HEADING'); ?></h1>
<div> <?php echo $this->message; ?> </div>
