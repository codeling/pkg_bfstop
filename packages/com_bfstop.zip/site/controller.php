<?php
defined('_JEXEC') or die;

class bfstopController extends JControllerLegacy {

	function display($cachable = false, $urlparams = false) {
		parent::display($cachable, $urlparams);
	}
}
