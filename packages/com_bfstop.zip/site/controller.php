<?php
defined('_JEXEC') or die;

class bfstopController extends JController {

	function display($cachable = false, $urlparams = false) {
		parent::display($cachable, $urlparams);
	}
}
