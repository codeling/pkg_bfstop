-- uninstall script for bfstop plugin

DROP TABLE IF EXISTS `#__bfstop_failedlogin`;

DROP TABLE IF EXISTS `#__bfstop_bannedip`;

DROP TABLE IF EXISTS `#__bfstop_unblock`;

DROP TABLE IF EXISTS `#__bfstop_unblock_token`;

DROP TABLE IF EXISTS `#__bfstop_whitelist`;

